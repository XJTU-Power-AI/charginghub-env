#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-pragmas"
#pragma ide diagnostic ignored "cert-msc50-cpp"
#pragma ide diagnostic ignored "cert-msc51-cpp"
#pragma ide diagnostic ignored "bugprone-integer-division"
#pragma ide diagnostic ignored "OCUnusedGlobalDeclarationInspection"
#pragma ide diagnostic ignored "cppcoreguidelines-narrowing-conversions"
//
// Created by tianzhaoming on 2021/7/15.
//

#include "SCP.h"
#include <iostream>
#include <string>
#include <utility>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <vector>
#include <random>
#include <cstdlib>
#include <ctime>

using namespace std;

vector<vector<double>> car_flow_possibility_list;
int no_use = Read2Vector::read("car_flow_possibility_list_save.csv", car_flow_possibility_list);
bool Use_Seed = true;
std::default_random_engine e;

////////////////////////////////////////////////////////////////////////////////////////////////
//float RandomUtil::uniform_rand(float rand_start, float rand_end, bool seed) {
////    cout << "seed is " << seed << endl;
//    int number_out;
//    int N = 999;
//    if (seed and Use_Seed) {
//        srand(time(nullptr));
//        Use_Seed = false;
////        cout << "nullptr is " << nullptr << endl;
//    }
//    float tr = rand() % (N + 1) / (float) (N);
//    tr = tr * (rand_end - rand_start) + rand_start;
//    return tr;
//}


////////////////////////////////////////////////////////////////////////////////////////////////
template<typename T>
int Read2Vector::read(const string &data_to_read, vector<vector<T> > &a) {
    vector<T> b;
    vector<string> row;
    string line;
    string filename;
    ifstream in(data_to_read);
    if (in.fail()) {
        cout << "File not found" << endl;
        return 1;
    }
    while (getline(in, line) && in.good()) {
        file_to_string(row, line, ',');  //把line里的单元格数字字符提取出来，“,”为单元格分隔符
//       for (int i = 0, length_temp = row.size(); i < length_temp; i++) {
        for (auto &i : row) {
            b.push_back(string_to_float(i));
        }
        a.push_back(b);
        b.clear();
    }
    in.close();
    return 0;
}

void Read2Vector::file_to_string(vector<string> &record, const string &line, char delimiter) {
    int linepos = 0;
    char c;
    int line_max = line.length();
    string cur_string;
    record.clear();
    while (linepos < line_max) {
        c = line[linepos];
        if (isdigit(c) || c == '.') {
            cur_string += c;
        } else if (c == delimiter && !cur_string.empty()) {
            record.push_back(cur_string);
            cur_string = "";
        }
        ++linepos;
    }
    if (!cur_string.empty())
        record.push_back(cur_string);
}

float Read2Vector::string_to_float(string str) {
    int i = 0, len = str.length();
    float sum = 0;
    while (i < len) {
        if (str[i] == '.') break;
        sum = sum * 10 + str[i] - '0';
        ++i;
    }
    ++i;
    float t, d = 1;
    while (i < len) {
        d *= 0.1;
        t = str[i] - '0';
        sum += t * d;
        ++i;
    }
    return sum;
}

void Read2Vector::generate() {
    std::random_device rd; //obtain a seed
    std::mt19937 gen(rd()); //mersenne_twister_engine
    std::uniform_real_distribution<> dist(-1.0, 1.0);

    ofstream outFile;
    outFile.open("test5000.csv", ios::out);
    // 5000*128
    for (int i = 1; i <= 5000; i++) {
        for (int j = 1; j <= 127; j++) {
            outFile << dist(gen) << ',';
        }
        outFile << dist(gen) << endl;
    }
    outFile.close();
}

////////////////////////////////////////////////////////////////////////////////////////////////
void Station::
make_init_list() {
    map<int, float> list1;
    map<int, float> list2;
    map<int, float> list3;
    map<int, float> list4;
    map<int, float> list5;
    map<int, float> list6;
    for (int i = 0; i < this->charge_number; i++) {
        list1.insert(make_pair(i, 0.0));// 是否有车
        list2.insert(make_pair(i, 0.0));// 是否充电
        list3.insert(make_pair(i, 0.0));// 紧急度
        list4.insert(make_pair(i, 0.0));// 分配
        list5.insert(make_pair(i, 0.0));// 充电功率
    }
    this->situation.insert(make_pair("car", list1));
    this->situation.insert(make_pair("charge", list2));
    this->situation.insert(make_pair("emergency", list3));
    this->situation.insert(make_pair("assign", list4));
    this->situation.insert(make_pair("power", list5));

}

////////////////////////////////////////////////////////////////////////////////////////////////
StationBase::StationBase(int charge_number, const string &position_class, bool wait) {
    this->station_time_hole = 0;
    this->charge_number = charge_number;
    this->load_assigned = 0;
    this->flow_in_number.clear();
//    this->positions.clear();
    this->no_charge_list.clear();
    this->no_charge_number = 0;
    this->empty_list.clear();
    this->empty_number = 0;
    this->min_power = 0;
    this->max_power = 0;
    this->charge_power = 0;
    this->car_number = 0;
    this->make_init_list();
//    this->set_position(position_class);
    this->show = false;
    this->wait = wait;
    this->line = 0;
    this->constant_charging = false;
    cout << "StationBase initialized!" << endl;
}

//void StationBase::set_position(const string &position_class) {
//    if (position_class == "fast" or position_class == "Fast" or position_class == "FAST") {
//        this->positions.clear();
//        for (int i = 0; i < this->charge_number; i++) {
//            this->positions.insert(make_pair("FP" + to_string(i), FastPile(i, this)));
//        }
//        cout << "fast position generated!" << endl;
//    } else if (position_class == "slow" or position_class == "Slow" or position_class == "SLOW") {
//        this->positions.clear();
//        for (int i = 0; i < this->charge_number; i++) {
//            this->positions.insert(make_pair("SP" + to_string(i), SlowPile(i, this)));
//        }
//        cout << "slow position generated!" << endl;
//    } else {
//        cout << "position class must be 'fast' or 'slow' " << endl;
//    }
//}

void StationBase::catch_load() {
    this->load_assigned = this->max_power;
}

void StationBase::catch_load(float load) {
    if (load > this->max_power) {
        load = this->max_power;
    } else if (load < this->min_power) {
        load = this->min_power;
    } else {
    }
    this->load_assigned = load;
}

void StationBase::calculate_output() {
    float now_power = 0;
    int number = 0;
    for (int i = 0; i < this->charge_number; i++) {
        if (this->situation["car"][i] > 0.5) {
            number += 1;
            if (this->situation["charge"][i] > 0.5) {
                now_power += this->situation["power"][i];
            }
        }
    }
    this->charge_power = now_power;
    this->car_number = number;
    cout << "virtual calculate_output" << endl;
}

void StationBase::print_situation() {
    PrintUtil::Print_Two_Dimension_Map<string, int, float>(this->situation);
    int first_size;
    int second_sizes = 0;
    vector<int> second_size;
    first_size = this->situation.size();
    for (auto &it_one : this->situation) {
        int size_temp = it_one.second.size();
        second_sizes += size_temp;
        second_size.push_back(size_temp);
    }
    cout << "situation fist size " << first_size << endl;
    cout << "situation second size " << second_sizes << endl;
    PrintUtil::Print_Vector(second_size);
    cout << "Station situation is already printed!" << endl;
}

void StationBase::tell_empty() {
    this->find_empty();
    if (this->show) {
        cout << "empty number " << this->empty_number << endl;
        PrintUtil::Print_Vector(this->empty_list);
    }
}

void StationBase::find_empty() {
    this->empty_list.clear();
    this->empty_number = 0;
    for (int i = 0; i < this->charge_number; i++) {
        if (this->situation["car"][i] <= 0.5) {
            this->empty_list.push_back(i);
            this->empty_number += 1;
        }
    }
}

void StationBase::tell_chargeable() {
    this->find_chargeable();
    if (this->show) {
        cout << "chargeable number " << this->no_charge_number << endl;
        PrintUtil::Print_Vector(this->no_charge_list);
    }
}

void StationBase::find_chargeable() {
    this->no_charge_list.clear();
    this->no_charge_number = 0;
    for (int i = 0; i < this->charge_number; i++) {
        if (this->situation["charge"][i] <= 0.5) {
            this->no_charge_list.push_back(i);
            this->no_charge_number += 1;
        }
    }
}

void StationBase::assign_car() {
    int assign_number;
    if (this->wait) {
        assign_number = min<int>((this->line + this->flow_in_number.back()), this->empty_number);
        this->line = this->line + this->flow_in_number.back() - assign_number;
        this->line = min<int>(this->line, this->max_line);
    } else {
        assign_number = min<int>(this->flow_in_number.back(), this->empty_number);
    }
    cout << "assign_number " << assign_number << endl;
    for (int i = 0; i < assign_number; i++) {
        this->situation["assign"][this->empty_list[i]] = 1;
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////
ChargePositionBase::ChargePositionBase(int position_input, Station *station_name_input) {
    this->position = position_input;
    this->station_name = station_name_input;
    this->arrive_soc = -1;
    this->target_soc = -1;
    this->current_soc = -1;
    this->current_power = -1;
    this->must_charge = false;
    this->emergency = -1;
    this->stay_time = -1;
    this->already_stay_time = -1;
}

void ChargePositionBase::pl_reset() {
    this->arrive_soc = -1;
    this->target_soc = -1;
    this->current_soc = -1;
    this->current_power = -1;
    this->must_charge = false;
    this->emergency = -1;
    this->stay_time = -1;
    this->already_stay_time = -1;
}

void ChargePositionBase::occupy_position() const {
    this->station_name->situation["car"][this->position] = 1;
    this->station_name->situation["assign"][this->position] = 0;
}

void ChargePositionBase::reset_position() {
    this->station_name->situation["car"][this->position] = 0;
    this->station_name->situation["charge"][this->position] = 0;
    this->station_name->situation["emergency"][this->position] = 0;
    this->station_name->situation["assign"][this->position] = 0;
    this->station_name->situation["power"][this->position] = 0;
    this->pl_reset();
}

void ChargePositionBase::occupy_charge() const {
    if (this->station_name->situation["car"][this->position] == 1) {
        this->station_name->situation["charge"][this->position] = 1;
    } else {
        cout << "position " << this->position << " has no car" << endl;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////
SlowPile::SlowPile(int position_input, Station *station_name_input) : ChargePositionBase(position_input,
                                                                                         station_name_input) {
}

int SlowPile::calculate_min_charging_time() {
    float needed_time = UtilSlow::slow_soc_to_time(this->target_soc, this->station_name->constant_charging) -
                        UtilSlow::slow_soc_to_time(this->current_soc, this->station_name->constant_charging);
    return ceil(needed_time);
}

void SlowPile::add_car() {
    this->arrive_soc = CarArriveRandom::mk_soc();
    this->current_soc = this->arrive_soc;
    this->target_soc = RandomUtil::uniform_rand(80, 100);
    int must_needed = calculate_min_charging_time();
    this->stay_time = must_needed + CarArriveRandom::mk_late_time("slow");
    this->already_stay_time = 0;
    this->occupy_position();
    this->station_name->situation["power"][this->position] = UtilSlow::slow_time_to_power(
            UtilSlow::slow_soc_to_time(this->current_soc, this->station_name->constant_charging),
            this->station_name->constant_charging);
}

void SlowPile::calculate_needed() {
    float needed_time = UtilSlow::slow_soc_to_time(this->target_soc, this->station_name->constant_charging) -
                        UtilSlow::slow_soc_to_time(this->current_soc, this->station_name->constant_charging);
    int time_left = this->stay_time - this->already_stay_time;

    if (needed_time > 0) {
        if (time_left <= ceil(needed_time)) {
            this->must_charge = true;
            this->emergency = 10;
            this->station_name->situation["emergency"][this->position] = 10;
        } else {
            this->must_charge = false;
            this->emergency = pow((needed_time / (float) time_left), 2);
            this->station_name->situation["emergency"][this->position] = pow((needed_time / (float) time_left), 2);
        }
    } else {
        this->station_name->situation["emergency"][this->position] = 0.0;
    }
}

void SlowPile::car_step() {
    int temp_time = UtilSlow::slow_soc_to_time(this->current_soc, this->station_name->constant_charging) + 1;
    this->current_soc = UtilSlow::slow_time_to_soc(temp_time, this->station_name->constant_charging);
    this->current_power = UtilSlow::slow_time_to_power(temp_time, this->station_name->constant_charging);
    this->station_name->situation["power"][this->position] = UtilSlow::slow_time_to_power(temp_time,
                                                                                          this->station_name->constant_charging);
    for (int i = 0; i < this->station_name->charge_number; i++) {
        this->station_name->situation["assign"][i] = 0;
    }
}

void SlowPile::remove_car() {
    this->already_stay_time += 1;
    int time_left = this->stay_time - this->already_stay_time;
    if (time_left <= 0) {
        if (ceil(this->current_soc) < floor(this->target_soc)) {
            cout << "slow charge is not complete " << endl;
            cout << "slow charge time " << time_left << endl;
            cout << "slow current " << this->current_soc << endl;
            cout << "slow target " << this->target_soc << endl;
        }
        this->reset_position();
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////
FastPile::FastPile(int position_input, Station *station_name_input) : ChargePositionBase(position_input,
                                                                                         station_name_input) {
}

int FastPile::calculate_min_charging_time() {
    float needed_time = UtilFast::fast_soc_to_time(this->target_soc, this->station_name->constant_charging) -
                        UtilFast::fast_soc_to_time(this->current_soc, this->station_name->constant_charging);
    return ceil(needed_time);
}

void FastPile::add_car() {
    this->arrive_soc = CarArriveRandom::mk_soc();
    this->current_soc = this->arrive_soc;
    this->target_soc = RandomUtil::uniform_rand(80, 100);
    int must_needed = calculate_min_charging_time();
    this->stay_time = must_needed + CarArriveRandom::mk_late_time("slow");
    this->already_stay_time = 0;
    this->occupy_position();
    this->station_name->situation["power"][this->position] = UtilFast::fast_time_to_power(
            UtilFast::fast_soc_to_time(this->current_soc, this->station_name->constant_charging),
            this->station_name->constant_charging);
}

void FastPile::calculate_needed() {
    float needed_time = UtilFast::fast_soc_to_time(this->target_soc, this->station_name->constant_charging) -
                        UtilFast::fast_soc_to_time(this->current_soc, this->station_name->constant_charging);
    int time_left = this->stay_time - this->already_stay_time;

    if (needed_time > 0) {
        if (time_left <= ceil(needed_time)) {
            this->must_charge = true;
            this->emergency = 10;
            this->station_name->situation["emergency"][this->position] = 10;
        } else {
            this->must_charge = false;
            this->emergency = pow((needed_time / (float) time_left), 2);
            this->station_name->situation["emergency"][this->position] = pow((needed_time / (float) time_left), 2);
        }
    } else {
        this->station_name->situation["emergency"][this->position] = 0.0;
    }
}

void FastPile::car_step() {
    int temp_time = UtilFast::fast_soc_to_time(this->current_soc, this->station_name->constant_charging) + 1;
    this->current_soc = UtilFast::fast_time_to_soc(temp_time, this->station_name->constant_charging);
    this->current_power = UtilFast::fast_time_to_power(temp_time, this->station_name->constant_charging);
    this->station_name->situation["power"][this->position] = UtilFast::fast_time_to_power(temp_time,
                                                                                          this->station_name->constant_charging);
    for (int i = 0; i < this->station_name->charge_number; i++) {
        this->station_name->situation["assign"][i] = 0;
    }
}

void FastPile::remove_car() {
    this->already_stay_time += 1;
    int time_left = this->stay_time - this->already_stay_time;
    if (time_left <= 0) {
        if (ceil(this->current_soc) < floor(this->target_soc)) {
            cout << "fast charge is not complete " << endl;
            cout << "fast charge time " << time_left << endl;
            cout << "fast current " << this->current_soc << endl;
            cout << "fast target " << this->target_soc << endl;
        }
        this->reset_position();
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////
float UtilSlow::slow_time_to_power(float charge_time, bool constant_power) {
    if (constant_power) {
        if (14.68 >= charge_time and charge_time >= 0) {
            return 5.254973139368931;
        } else {
            return 0;
        }
    } else {
        if (charge_time < 2.33 * 4) {
            return b_part1(charge_time / 4);
        } else if (charge_time < 3.67 * 4) {
            return b_part2(charge_time / 4);
        } else {
            return 0;
        }
    }
}

float UtilSlow::slow_time_to_soc(float charge_time, bool constant_power) {
    if (constant_power) {
        if (charge_time <= 0) {
            return 0;
        } else if (charge_time >= 14.68) {
            return 100;
        } else {
            return 100 * charge_time / 14.68;
        }
    } else {
        return 100 * c_hole(charge_time) / 19.285746346634653;
    }
}

float UtilSlow::slow_soc_to_time(float soc, bool constant_power) {
    if (constant_power) {
        if (soc <= 0) {
            return 0;
        } else if (soc >= 100) {
            return 14.68;
        } else {
            return 14.68 * soc / 100;
        }

    } else {
        if (soc < 0) {
            return 0;
        } else if (0 <= soc and soc <= 73.89239629561729) {
            return s_t_t_1(soc);
        } else if (73.89239629561729 < soc and soc <= 100) {
            return s_t_t_2(soc) + 0.2012016075138625 * (soc - 73.89239629561729) / 26.10760370438271;
        } else {
            return 14.68;
        }
    }
}

float UtilSlow::b_part1(float x) {
    return -0.002056 * pow(x, 4) + 0.00921 * pow(x, 3) + 0.03562 * pow(x, 2) + 0.02379 * x + 6.007;
}

float UtilSlow::b_part2(float x) {
    return (-4.041 * x + 21.1) / (x - 0.485);
}

float UtilSlow::c_part1(float x) {
    return -0.0004112 * pow(x, 5) + 0.0023025 * pow(x, 4) + (0.03562 / 3) * pow(x, 3) + 0.011895 * pow(x, 2) +
           6.007 * x;
}

float UtilSlow::c_part2(float x) {
    return -4.041 * x + 19.140115 * log(abs(x - 0.485)) + 11.943306312699628;
}

float UtilSlow::c_hole(float x) {
    if (x <= 0) {
        return 0;
    } else if (x <= 2.33 * 4) {
        return c_part1(x / 4);
    } else if (x <= 3.67 * 4) {
        return c_part2(x / 4);
    } else {
        return c_part2(3.67);
    }
}

float UtilSlow::s_t_t_1(float soc) {
    return (-4.276 * pow(10, -5)) * pow(soc, 2) + 0.1295 * soc;
}

float UtilSlow::s_t_t_2(float soc) {
    return (4.742 * pow(10, -6)) * pow(soc, 4) - 0.001529 * pow(soc, 3) + 0.1871 * pow(soc, 2) - 10.15 * soc + 213.1 +
           0.1787983924863248;
}

////////////////////////////////////////////////////////////////////////////////////////////////
float UtilFast::fast_time_to_power(float charge_time, bool constant_power) {
    if (constant_power) {
        if (3.4133333333333336 >= charge_time and charge_time >= 0) {
            return 36.44764034125146;
        } else {
            return 0;
        }
    } else {
        if (charge_time >= 0 and charge_time < (28.7 / 15)) {
            return a_part1(charge_time * 15);
        } else if (charge_time >= 0 and charge_time < (51.2 / 15)) {
            return a_part2(charge_time * 15);
        } else {
            return 0;
        }
    }
}


float UtilFast::fast_time_to_soc(float charge_time, bool constant_power) {
    if (constant_power) {
        if (charge_time <= 0) {
            return 0;
        } else if (charge_time >= 3.4133333333333336) {
            return 100;
        } else {
            return 100 * charge_time / 3.4133333333333336;
        }
    } else {
        if (charge_time <= 0) {
            return 0;
        } else if (charge_time <= 28.7 / 15) {
            return aa_part1(charge_time * 15) * (100 / aa_part2(51.2));
        } else if (charge_time <= 51.2 / 15) {
            return aa_part2(charge_time * 15) * (100 / aa_part2(51.2));
        } else {
            return 100;
        }
    }
}

float UtilFast::fast_soc_to_time(float soc, bool constant_power) {
    if (constant_power) {
        if (soc <= 0) {
            return 0;
        } else if (soc >= 100) {
            return 3.4133333333333336;
        } else {
            return 3.4133333333333336 * soc / 100;
        }

    } else {
        if (soc <= 0) {
            return 0;
        } else if (soc >= 100) {
            return 51.2 / 15;
        } else {
            return matlab_fitted_curve(norm_soc(soc));
        }

    }
}

float UtilFast::a_part1(float x) {
    return 0.7194 * exp(0.053 * x) + 47.78;
}

float UtilFast::a_part2(float x) {
    return 0.0002253 * pow(x, 4) - 0.03572 * pow(x, 3) + 2.016 * pow(x, 2) - 48.76 * x + 457.7;
}

float UtilFast::aa_part1(float x) {
    float aa_part1_c = (0.7194 / 0.053) * exp(0);
    return (0.7194 / 0.053) * exp(0.053 * x) + 50.15 * x - aa_part1_c;
}

float UtilFast::aa_part2(float x) {
    float aa_part2_c = aa_part1(28.7) -
                       ((0.0002253 / 5) * pow(28.7, 5) - (0.03572 / 4) * pow(28.7, 4) + (2.016 / 3) * pow(28.7, 3) -
                        (48.76 / 2) * pow(28.7, 2) + 457.7 * 28.7);
    return (0.0002253 / 5) * pow(x, 5) - (0.03572 / 4) * pow(x, 4) + (2.016 / 3) * pow(x, 3) - (48.76 / 2) * pow(x, 2) +
           457.7 * x + aa_part2_c;
}

float UtilFast::matlab_fitted_curve(float x) {
    float p1 = -18.18;
    float p2 = 9.559;
    float p3 = 48.99;
    float p4 = -62.97;
    float p5 = 29.09;
    float q1 = -23.9;
    float q2 = 56.48;
    float q3 = -50.12;
    float q4 = 18.96;
    float temp = (p1 * pow(x, 4) + p2 * pow(x, 3) + p3 * pow(x, 2) + p4 * x + p5) /
                 (pow(x, 4) + q1 * pow(x, 3) + q2 * pow(x, 2) + q3 * x + q4);
    return temp;
}

float UtilFast::norm_soc(float x) {
    float mean = 61.43;
    float std = 31.48;
    return (x - mean) / std;
}

////////////////////////////////////////////////////////////////////////////////////////////////
int PoissonNumber::give_car_number_wrt_poisson(int what_time) {
//    cout << "in in in in in " << endl;
    int car_max = 300;

//    vector<vector<double>>::iterator it = car_flow_possibility_list.begin() + what_time;
    auto it = car_flow_possibility_list.begin() + what_time;
    vector<double> compare_list = *it;
//    cout << "////////////////////////////" << endl;
//    PrintUtil::Print_Vector(compare_list);
//    cout << "////////////////////////////" << endl;
    float compare_possible = RandomUtil::uniform_rand(0, 1);
    int item_id = 0;
//    for (vector<double>::iterator item = compare_list.begin(); item != compare_list.end(); item++) {
    for (double &item : compare_list) {
//        cout << "*item" << item << endl;
//        cout << "item id " << item_id << endl;
        if (item >= compare_possible) {
            return item_id;
        }
        item_id++;
    }
//    cout << "car max " << car_max << endl;
    return car_max;
}

int PoissonNumber::ev_car_number_wrt_poisson(int what_time) {
    float possible_in = 0.1;
    float permeability = 0.2;
    float po_ev_number = possible_in * permeability * give_car_number_wrt_poisson(what_time);
//    cout << "po ev number is " << po_ev_number << endl;
    return round(po_ev_number);
}

int PoissonNumber::hv_car_number_wrt_poisson(int what_time) {
    float hv_possible_in = 0.7;
    float hv_permeability = 0.01;
    return round(hv_possible_in * hv_permeability * PoissonNumber::give_car_number_wrt_poisson(what_time));
}

////////////////////////////////////////////////////////////////////////////////////////////////
float CarArriveRandom::mk_soc() {
    std::normal_distribution<double> normal_distribution(7.0, 3.0);
    float driver_experience = normal_distribution(e);
    if (driver_experience < 1.0) {
        driver_experience = 1.0;
    } else if (driver_experience > 10.0) {
        driver_experience = 10.0;
    }
    float soc = 75.0 - 5.0 * driver_experience;
    return soc;
}

int CarArriveRandom::mk_late_time(const string &charge_type) {
    float car_number;
    if (charge_type == "slow" or charge_type == "Slow" or charge_type == "SLOW") {

        std::normal_distribution<float> normal_distribution(2.0, 2.0);
        car_number = normal_distribution(e);
    } else if (charge_type == "fast" or charge_type == "Fast" or charge_type == "FAST") {

        std::normal_distribution<float> normal_distribution(1.0, 1.0);
        car_number = normal_distribution(e);
    } else {
        cout << "position class must be 'fast' or 'slow' " << endl;
        car_number = 0.0;
    }
    int duration = max(0, (int) round(car_number));
    return duration;
}

int CarArriveRandom::init_station_car_number(int mu, int theta) {
    std::normal_distribution<float> normal_distribution(mu, 1.0);
    float car_number = normal_distribution(e);
    int temp = round(car_number);
    if (temp > mu + theta) {
        temp = mu + theta;
    } else if (temp < mu - theta) {
        temp = mu - theta;
    }
    return temp;
}

////////////////////////////////////////////////////////////////////////////////////////////////
SlowChargeStation::SlowChargeStation(int charge_number, const string &position_class, bool wait,
                                     bool constant_charging) : StationBase(charge_number, position_class, wait) {
    this->set_position(position_class);
    this->constant_charging = constant_charging;
    this->charge_power_upper_limit = 7;
    this->evs_reset();
    this->constant_power = 5.254973139368931;
    this->transformer_limit = this->constant_power * this->charge_number;
    cout << "SlowChargeStation initialized!" << endl;
}

void SlowChargeStation::set_position(const string &position_class) {
    this->positions.clear();
    for (int i = 0; i < this->charge_number; i++) {
        this->positions.insert(make_pair("SP" + to_string(i), SlowPile(i, this)));
    }
    cout << "slow position generated!" << endl;
}

void SlowChargeStation::receive_car(bool reset_evs) {
    this->tell_empty();
    int in_car;
    if (reset_evs) {
        in_car = CarArriveRandom::init_station_car_number(round(this->charge_number / 6));
    } else {
        int in_car_time = this->station_time_hole % 96;
        in_car = PoissonNumber::ev_car_number_wrt_poisson(in_car_time);
    }
    this->flow_in_number.push_back(in_car);
    this->assign_car();
    for (int assign_where = 0; assign_where < this->charge_number; assign_where++) {
        if (this->situation["assign"][assign_where] > 0.5) {
            this->positions.at("SP" + to_string(assign_where)).add_car();
        }
    }
    for (int i = 0; i < this->charge_number; i++) {
        this->situation["assign"][i] = 0;
    }
}

void SlowChargeStation::assign_on_off() {
    if (this->constant_charging) {
        for (int i = 0; i < this->charge_number; i++) {
            this->situation["charge"][i] = 0;
        }
        ///////////////////////////////  sort start
        map<int, float> emergency_temp = this->situation["emergency"];
        multimap<float, int> swap_emergency_temp;

        for (auto &it_one : emergency_temp) {
            swap_emergency_temp.insert(make_pair(-it_one.second, it_one.first));
        }

        vector<int> sort_number;
        sort_number.clear();

        for (auto &it : swap_emergency_temp) {
            sort_number.push_back(it.second);
        }
        ///////////////////////////////  sort end
        int constant_charge_number = round(this->load_assigned / this->constant_power);

        int assigned = 0;

        for (int have_car = 0; have_car < this->charge_number; have_car++) {
            if (this->situation["car"][sort_number[have_car]] == 1 and assigned < constant_charge_number) {
                this->situation["charge"][sort_number[have_car]] = 1;
                assigned += 1;
            }

        }
    } else {
        for (int i = 0; i < this->charge_number; i++) {
            this->situation["charge"][i] = 0;
        }
        vector<float> added_power;
        vector<int> added_power_index;
        tie(added_power, added_power_index) = this->rank_power_add();
        for (int assign_car = 0; assign_car < added_power.size(); assign_car++) {
            cout << "this->load_assigned " << this->load_assigned << endl;
            cout << "added_power[assign_car] " << added_power[assign_car] << endl;
            if (this->load_assigned + 0.0001 >= added_power[assign_car]) {
                this->situation["charge"][added_power_index[assign_car]] = 1;
            }
        }
    }
}

tuple<vector<float>, vector<int>> SlowChargeStation::rank_power_add() {
    ///////////////////////////////  sort start
    map<int, float> emergency_temp = this->situation["emergency"];
    multimap<float, int> swap_emergency_temp;

    for (auto &it_one : emergency_temp) {
        swap_emergency_temp.insert(make_pair(-it_one.second, it_one.first));
    }

    vector<int> sort_number;
    sort_number.clear();

    for (auto &it : swap_emergency_temp) {
        sort_number.push_back(it.second);
    }
    ///////////////////////////////  sort end
    vector<float> added_rank;
    float added_temp = 0;
    vector<int> added_number;
    for (int rank_count = 0; rank_count < this->charge_number; rank_count++) {
        if (this->situation["car"][sort_number[rank_count]] == 1) {
            added_temp += this->situation["power"][sort_number[rank_count]];
            added_rank.push_back(added_temp);
            added_number.push_back(sort_number[rank_count]);
        }
    }
    return {added_rank, added_number};
}

void SlowChargeStation::evs_step(float action, bool test) {
    this->calculate_output();
    this->catch_load(action);
    this->assign_on_off();
    if (!test) {
        for (int change_car = 0; change_car < this->charge_number; change_car++) {
            if (this->situation["charge"][change_car]) {
                this->positions.at("SP" + to_string(change_car)).car_step();
            }
            if (this->situation["car"][change_car]) {
                this->positions.at("SP" + to_string(change_car)).remove_car();
            }
        }
        this->receive_car();
        this->station_time_hole = (this->station_time_hole + 1) % 96;
    }
    this->calculate_output();
}

void SlowChargeStation::evs_reset() {
    this->flow_in_number.clear();
    this->line = 0;
    this->station_time_hole = 0;
    this->load_assigned = 0;
    this->no_charge_list.clear();
    this->no_charge_number = 0;
    this->empty_list.clear();
    this->empty_number = 0;
    this->min_power = 0;
    this->max_power = 0;
    this->charge_power = 0;
    this->car_number = 0;
    this->situation.clear();
    this->make_init_list();

    for (int i = 0; i < this->charge_number; i++) {
        this->positions.at("SP" + to_string(i)).pl_reset();
    }
    this->receive_car(true);
    this->calculate_output();
}

void SlowChargeStation::calculate_output() {
    for (int needed_where = 0; needed_where < this->charge_number; needed_where++) {
        if (this->situation["car"][needed_where] > 0.5) {
            this->positions.at("SP" + to_string(needed_where)).calculate_needed();
        }
    }
    float min_power = 0;
    float max_power = 0;
    float now_power = 0;
    int number = 0;

    for (int out_count = 0; out_count < this->charge_number; out_count++) {
        if (this->situation["car"][out_count] > 0.5) {
            number += 1;
            max_power += this->situation["power"][out_count];
            if (this->situation["emergency"][out_count] > 8) {
                min_power += this->situation["power"][out_count];
            }
            if (this->situation["charge"][out_count] <= 1.1 and this->situation["charge"][out_count] >= 0.9) {
                now_power += this->situation["power"][out_count];
            }
        }
    }

    this->min_power = min_power;
    this->max_power = max_power;
    this->charge_power = now_power;
    this->car_number = number;
}

////////////////////////////////////////////////////////////////////////////////////////////////
FastChargeStation::FastChargeStation(int charge_number, const string &position_class, bool wait,
                                     bool constant_charging) : StationBase(charge_number, position_class, wait) {
    this->set_position(position_class);
    this->constant_charging = constant_charging;
    this->charge_power_upper_limit = 60;
    this->evs_reset();
    this->constant_power = 36.44764034125146;
    this->transformer_limit = this->constant_power * this->charge_number;
    cout << "FastChargeStation initialized!" << endl;
}

void FastChargeStation::set_position(const string &position_class) {
    this->positions.clear();
    for (int i = 0; i < this->charge_number; i++) {
        this->positions.insert(make_pair("FP" + to_string(i), FastPile(i, this)));
    }
    cout << "fast position generated!" << endl;
}

void FastChargeStation::receive_car(bool reset_evs) {
    this->tell_empty();
    int in_car;
    if (reset_evs) {
        in_car = CarArriveRandom::init_station_car_number(round(this->charge_number / 6));
    } else {
        int in_car_time = this->station_time_hole % 96;
        in_car = PoissonNumber::ev_car_number_wrt_poisson(in_car_time);
    }
    this->flow_in_number.push_back(in_car);
    this->assign_car();
    for (int assign_where = 0; assign_where < this->charge_number; assign_where++) {
        if (this->situation["assign"][assign_where] > 0.5) {
            this->positions.at("FP" + to_string(assign_where)).add_car();
        }
    }
    for (int i = 0; i < this->charge_number; i++) {
        this->situation["assign"][i] = 0;
    }
}

void FastChargeStation::assign_on_off() {
    if (this->constant_charging) {
        for (int i = 0; i < this->charge_number; i++) {
            this->situation["charge"][i] = 0;
        }
        ///////////////////////////////  sort start
        map<int, float> emergency_temp = this->situation["emergency"];
        multimap<float, int> swap_emergency_temp;

        for (auto &it_one : emergency_temp) {
            swap_emergency_temp.insert(make_pair(-it_one.second, it_one.first));
        }

        vector<int> sort_number;
        sort_number.clear();

        for (auto &it : swap_emergency_temp) {
            sort_number.push_back(it.second);
        }
        ///////////////////////////////  sort end
        int constant_charge_number = round(this->load_assigned / this->constant_power);

        int assigned = 0;

        for (int have_car = 0; have_car < this->charge_number; have_car++) {
            if (this->situation["car"][sort_number[have_car]] == 1 and assigned < constant_charge_number) {
                this->situation["charge"][sort_number[have_car]] = 1;
                assigned += 1;
            }
        }
    } else {
        for (int i = 0; i < this->charge_number; i++) {
            this->situation["charge"][i] = 0;
        }
        vector<float> added_power;
        vector<int> added_power_index;
        tie(added_power, added_power_index) = this->rank_power_add();
        for (int assign_car = 0; assign_car < added_power.size(); assign_car++) {
            cout << "this->load_assigned " << this->load_assigned << endl;
            cout << "added_power[assign_car] " << added_power[assign_car] << endl;
            if (this->load_assigned + 0.0001 >= added_power[assign_car]) {
                this->situation["charge"][added_power_index[assign_car]] = 1;
            }
        }
    }
}

tuple<vector<float>, vector<int>> FastChargeStation::rank_power_add() {
    ///////////////////////////////  sort start
    map<int, float> emergency_temp = this->situation["emergency"];
    multimap<float, int> swap_emergency_temp;

    for (auto &it_one : emergency_temp) {
        swap_emergency_temp.insert(make_pair(-it_one.second, it_one.first));
    }

    vector<int> sort_number;
    sort_number.clear();

    for (auto &it : swap_emergency_temp) {
        sort_number.push_back(it.second);
    }
    ///////////////////////////////  sort end
    vector<float> added_rank;
    float added_temp = 0;
    vector<int> added_number;
    for (int rank_count = 0; rank_count < this->charge_number; rank_count++) {
        if (this->situation["car"][sort_number[rank_count]] == 1) {
            added_temp += this->situation["power"][sort_number[rank_count]];
            added_rank.push_back(added_temp);
            added_number.push_back(sort_number[rank_count]);
        }
    }
    return {added_rank, added_number};
}

void FastChargeStation::evs_step(float action, bool test) {
    this->calculate_output();
    this->catch_load(action);
    this->assign_on_off();
    if (!test) {
        for (int change_car = 0; change_car < this->charge_number; change_car++) {
            if (this->situation["charge"][change_car]) {
                this->positions.at("FP" + to_string(change_car)).car_step();
            }
            if (this->situation["car"][change_car]) {
                this->positions.at("FP" + to_string(change_car)).remove_car();
            }
        }
        this->receive_car();
        this->station_time_hole = (this->station_time_hole + 1) % 96;
    }
    this->calculate_output();
}

void FastChargeStation::evs_reset() {
    this->flow_in_number.clear();
    this->line = 0;
    this->station_time_hole = 0;
    this->load_assigned = 0;
    this->no_charge_list.clear();
    this->no_charge_number = 0;
    this->empty_list.clear();
    this->empty_number = 0;
    this->min_power = 0;
    this->max_power = 0;
    this->charge_power = 0;
    this->car_number = 0;
    this->situation.clear();
    this->make_init_list();

    for (int i = 0; i < this->charge_number; i++) {
        this->positions.at("FP" + to_string(i)).pl_reset();
    }
    this->receive_car(true);
    this->calculate_output();
}

void FastChargeStation::calculate_output() {
    for (int needed_where = 0; needed_where < this->charge_number; needed_where++) {
        if (this->situation["car"][needed_where] > 0.5) {
            this->positions.at("FP" + to_string(needed_where)).calculate_needed();
        }
    }
    float min_power = 0;
    float max_power = 0;
    float now_power = 0;
    int number = 0;

    for (int out_count = 0; out_count < this->charge_number; out_count++) {
        if (this->situation["car"][out_count] > 0.5) {
            number += 1;
            max_power += this->situation["power"][out_count];
            if (this->situation["emergency"][out_count] > 8) {
                min_power += this->situation["power"][out_count];
            }
            if (this->situation["charge"][out_count] <= 1.1 and this->situation["charge"][out_count] >= 0.9) {
                now_power += this->situation["power"][out_count];
            }
        }
    }

    this->min_power = min_power;
    this->max_power = max_power;
    this->charge_power = now_power;
    this->car_number = number;
}

////////////////////////////////////////////////////////////////////////////////////////////Fast

#pragma clang diagnostic pop


