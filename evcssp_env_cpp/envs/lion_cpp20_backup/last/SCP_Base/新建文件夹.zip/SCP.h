//
// Created by tianzhaoming on 2021/7/15.
//

#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCUnusedGlobalDeclarationInspection"
#ifndef LION_CPP20_SCP_H
#define LION_CPP20_SCP_H

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <tuple>

using namespace std;

// tested
class RandomUtil {
public:
//    static float uniform_rand(float rand_start, float rand_end, bool seed = true);
    static float uniform_rand(float rand_start, float rand_end, bool seed = true) {
//    cout << "seed is " << seed << endl;
        int number_out;
        bool Use_Seed = true;
        int N = 999;
        if (seed and Use_Seed) {
            srand(time(nullptr));
            Use_Seed = false;
//        cout << "nullptr is " << nullptr << endl;
        }
        float tr = rand() % (N + 1) / (float) (N);
        tr = tr * (rand_end - rand_start) + rand_start;
        return tr;
    }
};


// tested
class PrintUtil {
public:
    template<typename T1, typename T2, typename T3>
    static void Print_Two_Dimension_Map(map<T1, map<T2, T3>> &map_to_print) {
        cout << "the two dimension map is" << endl;
        for (auto &it_one : map_to_print) {
            cout << "key_one = " << it_one.first << endl;
            for (auto &it_second : it_one.second) {
                cout << "key_second = " << it_second.first << " value = " << it_second.second << endl;
            }
        }
        cout << endl;
    }

    template<typename T1, typename T2>
    static void Print_Map(map<T1, T2> &map_to_print) {
        cout << "the map is" << endl;
        for (auto &it : map_to_print) {
            cout << "key = " << it.first << " value = " << it.second << endl;
        }
        cout << endl;
    }

    template<typename T>
    static void Print_Vector(vector<T> &v) {
        cout << "the vector is" << endl;
        for (T &it : v) {
            cout << it << " ";
        }
        cout << endl;
    }

    template<typename T>
    static void Print_Two_Dimension_Vector(vector<vector<T>> &vector_to_print) {
        cout << "the two dimension vector is" << endl;
        for (auto &temp : vector_to_print) {
            for (auto &te : temp) {
                cout << te << " ";
            }
            cout << endl;
        }
    }
};

// tested
class Read2Vector {
public:
    template<typename T>
    static int read(const string &data_to_read, vector<vector<T> > &a);

    static void file_to_string(vector<string> &record, const string &line, char delimiter);

    static float string_to_float(string str);

    static void generate();
};

// tested
class Station {
public:
    int charge_number;
    map<string, map<int, float>> situation;
    int station_time_hole;
    float load_assigned;
//    map<string, map<int, float>> situation;
    vector<int> flow_in_number;
    vector<int> no_charge_list;
    int no_charge_number;
    vector<int> empty_list;
    int empty_number;
    float min_power;
    float max_power;
    float charge_power;
    int car_number;
    bool show;
    bool wait;
    int line;
    bool constant_charging;
    int max_line = 10;


    virtual void print_situation() {
        cout << "virtual print_situation" << endl;
    };
protected:
    void make_init_list();
};

// tested
class ChargePositionBase {
public:
    int position;
    Station *station_name;
//    int arrive_time;
    float arrive_soc;
//    int target_leave_time;
    float target_soc;
//    float charged_time;
    float current_soc;
    float current_power;
    bool must_charge;
    float emergency;
    int stay_time;
    int already_stay_time;

    ChargePositionBase(int position_input, Station *station_name_input);

    void pl_reset();

    void reset_position();

    void occupy_charge() const;

    virtual void add_car() {
        cout << "virtual add_car" << endl;
    };

    virtual void calculate_needed() {
        cout << "virtual calculate_needed" << endl;
    };

    virtual void car_step() {
        cout << "virtual car_step" << endl;
    };

    virtual void remove_car() {
        cout << "virtual remove_car" << endl;
    };

protected:
    void occupy_position() const;

};

// tested
class StationBase : public Station {
public:
//    map<string, ChargePositionBase> positions;

    StationBase(int charge_number, const string &position_class, bool wait);

    void catch_load();

    void catch_load(float load);

    virtual void calculate_output();

    void print_situation() override;

    void tell_empty();

    void tell_chargeable();

    void assign_car();

    virtual void receive_car() {
        cout << "virtual receive_car" << endl;
    };

    virtual void assign_on_off() {
        cout << "virtual assign_on_off" << endl;
    };


protected:
//    void set_position(const string &position_class);

    void find_empty();

    void find_chargeable();

};

// tested
class SlowPile : public ChargePositionBase {
public:
    SlowPile(int position_input, Station *station_name_input);

    void add_car() override;

    void calculate_needed() override;

    void car_step() override;

    void remove_car() override;

private:
    int calculate_min_charging_time();
};

// tested
class FastPile : public ChargePositionBase {
public:
    FastPile(int position_input, Station *station_name_input);

    void add_car() override;

    void calculate_needed() override;

    void car_step() override;

    void remove_car() override;

private:
    int calculate_min_charging_time();

};

// tested
class UtilSlow {
public:
    static float slow_time_to_power(float charge_time, bool constant_power = false);

    static float slow_time_to_soc(float charge_time, bool constant_power = false);

    static float slow_soc_to_time(float soc, bool constant_power = false);

private:
    static float b_part1(float x);

    static float b_part2(float x);

    static float c_part1(float x);

    static float c_part2(float x);

    static float c_hole(float x);

    static float s_t_t_1(float soc);

    static float s_t_t_2(float soc);

};

// tested
class UtilFast {
public:
    static float fast_time_to_power(float charge_time, bool constant_power = false);

    static float fast_time_to_soc(float charge_time, bool constant_power = false);

    static float fast_soc_to_time(float soc, bool constant_power = false);

private:
    static float a_part1(float x);

    static float a_part2(float x);

    static float aa_part1(float x);

    static float aa_part2(float x);

    static float matlab_fitted_curve(float x);

    static float norm_soc(float x);
};

// tested
class PoissonNumber {
public:
    static int give_car_number_wrt_poisson(int what_time);

    static int ev_car_number_wrt_poisson(int what_time);

    static int hv_car_number_wrt_poisson(int what_time);
};

// tested
class CarArriveRandom {
public:
    static float mk_soc();

    static int mk_late_time(const string &charge_type);

    static int init_station_car_number(int mu = 25, int theta = 3);
};


class SlowChargeStation : public StationBase {
public:
    float charge_power_upper_limit;
    float constant_power;
    float transformer_limit;
    map<string, SlowPile> positions;

    explicit SlowChargeStation(int charge_number, const string &position_class = "slow", bool wait = true,
                               bool constant_charging = false);

    void evs_step(float action, bool test = false);

    void evs_reset();

    void calculate_output() override;

private:
    void set_position(const string &position_class);

    void receive_car(bool reset_evs = false);

    void assign_on_off() override;

    tuple<vector<float>, vector<int>> rank_power_add();
};

class FastChargeStation : public StationBase {
public:
    float charge_power_upper_limit;
    float constant_power;
    float transformer_limit;
    map<string, FastPile> positions;

    explicit FastChargeStation(int charge_number, const string &position_class = "fast", bool wait = true,
                               bool constant_charging = false);

    void evs_step(float action, bool test = false);

    void evs_reset();

    void calculate_output() override;

private:
    void set_position(const string &position_class);

    void receive_car(bool reset_evs = false);

    void assign_on_off() override;

    tuple<vector<float>, vector<int>> rank_power_add();
};

#endif //LION_CPP20_SCP_H

#pragma clang diagnostic pop